package com.ite.videojuegos.modelo.beans;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;

/**
 * The persistent class for the perfil database table.
 * 
 */
@Entity
@NamedQuery(name = "Perfil.findAll", query = "SELECT p FROM Perfil p")
public class Perfil implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idperfil;

	private String nombre;

	// bi-directional many-to-many association to Usuario
	@ManyToMany(mappedBy = "perfils")
	private List<Usuario> usuarios;

	public Perfil() {
	}

	public int getIdperfil() {
		return this.idperfil;
	}

	public void setIdperfil(int idperfil) {
		this.idperfil = idperfil;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Usuario> getUsuarios() {
		return this.usuarios;
	}

	public void setUsuarios(List<Usuario> usuarios) {
		this.usuarios = usuarios;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + idperfil;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Perfil))
			return false;
		Perfil other = (Perfil) obj;
		if (idperfil != other.idperfil)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Perfil [idperfil=" + idperfil + ", nombre=" + nombre + ", usuarios=" + usuarios + "]";
	}

}