package com.ite.videojuegos.modelo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ite.videojuegos.modelo.beans.Compra;

//Repositorio de las compras
public interface CompraRepository extends JpaRepository<Compra, Integer>{

}
