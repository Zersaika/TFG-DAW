package com.ite.videojuegos.controlador;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ite.videojuegos.modelo.beans.Perfil;
import com.ite.videojuegos.modelo.beans.Usuario;
import com.ite.videojuegos.modelo.beans.Videojuego;
import com.ite.videojuegos.modelo.dao.IntGenero;
import com.ite.videojuegos.modelo.dao.IntPerfil;
import com.ite.videojuegos.modelo.dao.IntUsuario;
import com.ite.videojuegos.modelo.dao.IntVideojuego;

//Controlador del inicio
@Controller
public class ControladorInicio {

	@Autowired
	private IntVideojuego vdao;
	@Autowired
	private IntGenero gdao;
	@Autowired
	private IntUsuario udao;
	@Autowired
	private IntPerfil pdao;

	// Metodo para el inicio de la app, se encarga de añadir al usuario que inicia
	// sesion y añadir los videojuegos, generos y perfiles a la app
	@GetMapping("/")
	public String entrada(Authentication aut, HttpSession sesion, Model model) {
		// Si no esta autentificado no añadimos en sesion al usuario
		if (aut != null) {
			sesion.setAttribute("usuario", udao.verUsuario(aut.getName()));
		}

		// Creamos una lista de videojuegos en sesion
		@SuppressWarnings("unchecked")
		List<Videojuego> carrito = (List<Videojuego>) sesion.getAttribute("carrito");

		// Si esta vacia es de tipo arraylist
		if (carrito == null) {
			carrito = new ArrayList<Videojuego>();
		}

		sesion.setAttribute("generos", gdao.verGeneros());
		sesion.setAttribute("perfiles", pdao.verPerfiles());
		model.addAttribute("videojuegos", vdao.verVideojuegos());

		return "inicio";

	}

	// Metodo que nos lleva a la pagina del login
	@GetMapping("/login")
	public String login() {

		return "login";

	}

	// Metodo que nos muestra el detalle de un videojuego
	@GetMapping("/detalle/{id}")
	public String detalle(@PathVariable("id") int id, Model model) {

		// Encontramos el videojuego mediante su id
		model.addAttribute("videojuego", vdao.verVideojuego(id));

		return "detalleVideojuego";

	}

	// Metodo que nos busca cualquier titulo de un videojuego mediante una cadena de
	// texto o numeros
	@PostMapping("/buscar")
	public String buscar(@RequestParam("cadena") String cadena, Model model) {

		model.addAttribute("videojuegos", vdao.verVideojuegosPorTitulo(cadena));

		return "inicio";

	}

	// Metodo que nos busca todos los videojuegos de un genero en concreto
	@GetMapping("/verVideojuegos/{genero}")
	public String buscarPorGenero(@PathVariable("genero") int genero, Model model) {

		model.addAttribute("videojuegos", vdao.verVideojuegosPorGenero(genero));

		return "inicio";

	}

	// Metodo que redirige a la pagina de registro
	@GetMapping("/registro")
	public String registro(HttpSession sesion) {

		sesion.setAttribute("perfiles", pdao.verPerfiles());

		return "registro";

	}

	// Metodo que permite al cliente crear usuarios
	@PostMapping("/registro")
	public String procRegistro(Usuario usuarioaux, Perfil perfil, RedirectAttributes rattr) {

		// Creamos usuario
		Usuario usuario = new Usuario();
		usuario.setUsuario(usuarioaux.getUsuario());
		usuario.setNombre(usuarioaux.getNombre());
		usuario.setApellido(usuarioaux.getApellido());
		usuario.setContrasena("{noop}" + usuarioaux.getContrasena());
		usuario.setDireccion(usuarioaux.getDireccion());
		usuario.setEmail(usuarioaux.getEmail());
		usuario.setFechaAlta(new Date());
		usuario.setTelefono(usuarioaux.getTelefono());
		usuario.setDinero(0.00);

		// Añadimos un tipo de perfil de usuario
		List<Perfil> lista = new ArrayList<Perfil>();
		Perfil p = pdao.verPerfil(perfil.getIdperfil());
		lista.add(p);
		usuario.setPerfils(lista);

		// Lo creamos
		int reg = udao.crear(usuario);
		if (reg == 0) {
			System.out.println("Usuario no añadido");
			rattr.addFlashAttribute("mensaje", "El usuario no se ha creado/Nombre de usuario ya existe");
		} else {
			System.out.println("Usuario añadido");
			rattr.addFlashAttribute("mensaje", "El usuario se ha creado");
		}

		return "redirect:/";

	}

}
