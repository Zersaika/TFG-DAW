package com.ite.videojuegos.modelo.beans;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the compras database table.
 * 
 */
@Entity
@Table(name = "compras")
@NamedQuery(name = "Compra.findAll", query = "SELECT c FROM Compra c")
public class Compra implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idcompra;

	private String asunto;

	// uni-directional many-to-one association to Usuario
	@ManyToOne
	@JoinColumn(name = "USUARIO")
	private Usuario usuarioBean;

	// uni-directional many-to-one association to Videojuego
	@ManyToOne
	@JoinColumn(name = "IDVIDEOJUEGO")
	private Videojuego videojuego;

	public Compra() {
	}

	public int getIdcompra() {
		return this.idcompra;
	}

	public void setIdcompra(int idcompra) {
		this.idcompra = idcompra;
	}

	public String getAsunto() {
		return this.asunto;
	}

	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}

	public Usuario getUsuarioBean() {
		return this.usuarioBean;
	}

	public void setUsuarioBean(Usuario usuarioBean) {
		this.usuarioBean = usuarioBean;
	}

	public Videojuego getVideojuego() {
		return this.videojuego;
	}

	public void setVideojuego(Videojuego videojuego) {
		this.videojuego = videojuego;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + idcompra;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Compra))
			return false;
		Compra other = (Compra) obj;
		if (idcompra != other.idcompra)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Compra [idcompra=" + idcompra + ", asunto=" + asunto + ", usuarioBean=" + usuarioBean + ", videojuego="
				+ videojuego + "]";
	}

}