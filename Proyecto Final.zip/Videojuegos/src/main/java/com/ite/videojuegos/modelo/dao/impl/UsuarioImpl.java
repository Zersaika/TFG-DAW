package com.ite.videojuegos.modelo.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ite.videojuegos.modelo.beans.Perfil;
import com.ite.videojuegos.modelo.beans.Usuario;
import com.ite.videojuegos.modelo.dao.IntUsuario;
import com.ite.videojuegos.modelo.repository.UsuarioRepository;

//Implementacion de la interfaz de los usuarios
@Repository
public class UsuarioImpl implements IntUsuario {

	@Autowired
	UsuarioRepository urepo;

	// Metodo que permite ver un usuario por un nombre de usuario
	@Override
	public Usuario verUsuario(String usuario) {
		// TODO Auto-generated method stub
		return urepo.findById(usuario).orElse(null);
	}

	// Metodo que permite crear un usuario en la base de datos
	@Override
	public int crear(Usuario usuario) {
		int crear = 0;
		if (verUsuario(usuario.getUsuario()) == null) {
			urepo.save(usuario);
			crear = 1;
		}
		return crear;
	}

	// Metodo que permite modificar un usuario en la base de datos
	@Override
	public int modificar(Usuario usuario) {
		int modificar = 0;
		if (verUsuario(usuario.getUsuario()) != null) {
			urepo.save(usuario);
			modificar = 1;
		}
		return modificar;
	}

	// Metodo que permite eliminar un usuario en la base de datos
	@Override
	public int eliminar(String usuario) {
		int eliminar = 0;
		if (verUsuario(usuario) != null) {
			try {
				urepo.deleteById(usuario);
				eliminar = 1;
			} catch (Exception e) {
				eliminar = 0;
			}
		}
		return eliminar;
	}

	// Metodo que devuelve todos los usuarios registrados
	@Override
	public List<Usuario> mostrarTodosUsuarios() {
		// TODO Auto-generated method stub
		return urepo.findAll();
	}

	// Metodo que permite ver el perfil de los usuarios mediante su nombre de
	// usuario
	@Override
	public List<Perfil> mostrarPerfilUsuario(String usuario) {
		// TODO Auto-generated method stub
		return urepo.findById(usuario).get().getPerfils();
	}

}
