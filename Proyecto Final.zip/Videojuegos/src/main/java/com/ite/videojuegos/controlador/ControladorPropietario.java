package com.ite.videojuegos.controlador;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ite.videojuegos.modelo.beans.Genero;
import com.ite.videojuegos.modelo.beans.Videojuego;
import com.ite.videojuegos.modelo.dao.IntCompra;
import com.ite.videojuegos.modelo.dao.IntGenero;
import com.ite.videojuegos.modelo.dao.IntVenta;
import com.ite.videojuegos.modelo.dao.IntVideojuego;
import com.ite.videojuegos.modelo.dto.SubirArchivo;

//Controlador del propietario
@Controller
@RequestMapping("/propietario")
public class ControladorPropietario {

	@Autowired
	private IntGenero gdao;

	@Autowired
	private IntVideojuego vdao;

	@Autowired
	private IntCompra cdao;

	@Autowired
	private IntVenta vedao;

	// Metodo que redirige a la pagina de añadir un videojuego
	@GetMapping("/añadirVideojuego")
	public String añadirVideojuego() {
		return "añadirVideojuego";

	}

	// Metodo para añadir un videojuego
	@PostMapping("/añadirVideojuego")
	public String procAñadirVideojuego(@ModelAttribute Videojuego videojuego, BindingResult result,
			@RequestParam("imagen") MultipartFile multipartFile, Genero genero, RedirectAttributes rattr)
			throws IOException {

		// Por parametro cogemos la imagen y cogemos su nombre
		String archivo = StringUtils.cleanPath(multipartFile.getOriginalFilename());
		// String donde se va a subir las imagenes
		String directorio = "app-videojuegos/img/";

		if (archivo.isEmpty()) {
			System.out.println("No hay imagen asignada");
		} else {

			// Asignamos la imagen al videojuego
			videojuego.setImagen(archivo);
			// Guardamos el archivo en el directorio con el mismo nombre
			SubirArchivo.guardarArchivo(directorio, archivo, multipartFile);

		}

		// Asignamos un genero y lo creamos
		videojuego.setGenero(gdao.verGenero(genero.getIdgenero()));

		int reg = vdao.crear(videojuego);
		if (reg == 0) {
			System.out.println("Videojuego no añadido");
			rattr.addFlashAttribute("mensaje", "El Videojuego no se ha añadido");
		} else {
			System.out.println("Videojuego añadido");
			rattr.addFlashAttribute("mensaje", "El Videojuego se ha añadido");
		}

		return "redirect:/";

	}

	// Metodo para eliminar un videojuego mediante su id
	@GetMapping("/eliminarVideojuego/{id}")
	public String eliminarVideojuego(@PathVariable("id") int id, Model model, RedirectAttributes rattr) {

		int reg = vdao.eliminar(id);
		if (reg == 0) {
			System.out.println("Videojuego no eliminado");
			rattr.addFlashAttribute("mensaje", "El Videojuego no se puede eliminar si existe una compra con el");

		} else {
			System.out.println("Videojuego eliminado");
			rattr.addFlashAttribute("mensaje", "El Videojuego se ha eliminado");
		}

		return "redirect:/";

	}

	// Metodo que redirige para modificar un videojuego
	@GetMapping("/modificarVideojuego/{id}")
	public String modificarVideojuego(@PathVariable("id") int id, Model model) {
		model.addAttribute("videojuego", vdao.verVideojuego(id));

		return "modificarVideojuego";

	}

	// Metodo para modificar un videojuego mediante su id
	@PostMapping("/modificarVideojuego/{id}")
	public String procModificarVideojuego(@PathVariable("id") int id, Model model,
			@ModelAttribute Videojuego videojuego, BindingResult result,
			@RequestParam("imagen") MultipartFile multipartFile, Genero genero, RedirectAttributes rattr)
			throws IOException {
		Videojuego v = vdao.verVideojuego(id);

		String archivo = StringUtils.cleanPath(multipartFile.getOriginalFilename());
		String directorio = "app-videojuegos/img/";

		// Si algun hueco esta en blanco no modifcamos ese dato

		if (archivo.isEmpty()) {
			System.out.println("No hay que cambiar la imagen");
		} else {
			v.setImagen(archivo);
			SubirArchivo.guardarArchivo(directorio, archivo, multipartFile);
		}

		if (videojuego.getDescripcion().isEmpty()) {
			System.out.println("No hay que cambiar la descripcion");
		} else {
			v.setDescripcion(videojuego.getDescripcion());
		}

		if (videojuego.getDistribuidora().isEmpty()) {
			System.out.println("No hay que cambiar la distribuidora");
		} else {
			v.setDistribuidora(videojuego.getDistribuidora());
		}

		if (videojuego.getPrecio() == 0) {
			System.out.println("No hay que cambiar el precio");
		} else {
			v.setPrecio(videojuego.getPrecio());
		}

		if (videojuego.getTitulo().isEmpty()) {
			System.out.println("No hay que cambiar el titulo");
		} else {
			v.setTitulo(videojuego.getTitulo());
		}

		if (genero.getIdgenero() == 0) {
			System.out.println("No hay que cambiar el genero");
		} else {
			v.setGenero(gdao.verGenero(genero.getIdgenero()));
		}

		int reg = vdao.modificar(v);
		if (reg == 0) {
			System.out.println("Videojuego no modificado");
			rattr.addFlashAttribute("mensaje", "El Videojuego no se ha modificado");
		} else {
			System.out.println("Videojuego modificado");
			rattr.addFlashAttribute("mensaje", "El Videojuego se ha modificado");
		}

		return "redirect:/";

	}

	// Metodo que redirige a la pgina de añadir genero
	@GetMapping("/añadirGenero")
	public String añadirGenero() {

		return "añadirGenero";

	}

	// Metodo que añade los generos de los videojuegos
	@PostMapping("/añadirGenero")
	public String procAñadirGenero(Genero genero, RedirectAttributes rattr) {

		int reg = gdao.crear(genero);
		if (reg == 0) {
			System.out.println("Genero no añadido");
			rattr.addFlashAttribute("mensaje", "El genero no se ha añadido");
		} else {
			System.out.println("Genero añadido");
			rattr.addFlashAttribute("mensaje", "El genero se ha añadido");
		}

		return "redirect:/";

	}

	// Metodo para eliminar un genero mediante su id
	@GetMapping("/eliminarGenero/{id}")
	public String eliminarGenero(@PathVariable("id") int id, RedirectAttributes rattr) {

		int reg = gdao.eliminar(id);
		if (reg == 0) {
			System.out.println("Genero no eliminado");
			rattr.addFlashAttribute("mensaje",
					"El genero no se puede eliminar si existe una compra de un videojuego con el");
		} else {
			System.out.println("Genero eliminado");
			rattr.addFlashAttribute("mensaje", "El genero se ha eliminado");
		}

		return "redirect:/propietario/verGeneros";

	}

	// Metodo que redirige a la pagina de modificar genero
	@GetMapping("/modificarGenero/{id}")
	public String modificarGenero(@PathVariable("id") int id, Model model) {
		model.addAttribute("genero", gdao.verGenero(id));

		return "modificarGenero";

	}

	// Metodo para modificar un genero mediante su id
	@PostMapping("/modificarGenero/{id}")
	public String procModificarGenero(@PathVariable("id") int id, Genero genero, RedirectAttributes rattr) {
		Genero g = gdao.verGenero(id);

		if (genero.getNombregenero().isEmpty()) {
			System.out.println("No hay que cambiar el nombre");
		} else {
			g.setNombregenero(genero.getNombregenero());
		}
		int reg = gdao.modificar(g);
		if (reg == 0) {
			System.out.println("Genero no modificado");
			rattr.addFlashAttribute("mensaje", "El genero no se ha modificado");
		} else {
			System.out.println("Genero modificado");
			rattr.addFlashAttribute("mensaje", "El genero se ha modificado");
		}
		return "redirect:/propietario/verGeneros";

	}

	// Metodo para visualizar una lista de los generos
	@GetMapping("/verGeneros")
	public String verGenero(Model model) {

		model.addAttribute("generos", gdao.verGeneros());
		return "listaGeneros";

	}

	// Metodo para visualizar una lista de las compras
	@GetMapping("/compras")
	public String compras(Model model) {
		model.addAttribute("compras", cdao.verCompras());
		return "listaCompras";

	}

	// Metodo para visualizar uan lista de las ventas
	@GetMapping("/ventas")
	public String ventas(Model model) {
		model.addAttribute("ventas", vedao.verVentas());
		return "listaVentas";

	}

}
