package com.ite.videojuegos.modelo.dao;

import java.util.List;

import com.ite.videojuegos.modelo.beans.Perfil;
import com.ite.videojuegos.modelo.beans.Usuario;

//Interfaz de los usuarios
public interface IntUsuario {

	List<Usuario> mostrarTodosUsuarios();

	List<Perfil> mostrarPerfilUsuario(String usuario);

	Usuario verUsuario(String usuario);

	int crear(Usuario usuario);

	int modificar(Usuario usuario);

	int eliminar(String usuario);

}
