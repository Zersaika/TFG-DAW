package com.ite.videojuegos.modelo.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ite.videojuegos.modelo.beans.Perfil;
import com.ite.videojuegos.modelo.dao.IntPerfil;
import com.ite.videojuegos.modelo.repository.PerfilRepository;

//Implementacion de la interfaz de los perfiles
@Repository
public class PerfilImpl implements IntPerfil {

	@Autowired
	PerfilRepository prepo;

	// Maetodo que devuelve una lista con todos los perfiles
	@Override
	public List<Perfil> verPerfiles() {
		// TODO Auto-generated method stub
		return prepo.findAll();
	}

	// Metodo que permite ver un perfil mediante un id
	@Override
	public Perfil verPerfil(int id) {
		// TODO Auto-generated method stub
		return prepo.findById(id).orElse(null);
	}

}
