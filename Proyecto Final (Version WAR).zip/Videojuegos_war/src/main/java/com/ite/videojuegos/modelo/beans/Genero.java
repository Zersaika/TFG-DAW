package com.ite.videojuegos.modelo.beans;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the genero database table.
 * 
 */
@Entity
@NamedQuery(name = "Genero.findAll", query = "SELECT g FROM Genero g")
public class Genero implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idgenero;

	private String nombregenero;

	public Genero() {
	}

	public int getIdgenero() {
		return this.idgenero;
	}

	public void setIdgenero(int idgenero) {
		this.idgenero = idgenero;
	}

	public String getNombregenero() {
		return this.nombregenero;
	}

	public void setNombregenero(String nombregenero) {
		this.nombregenero = nombregenero;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + idgenero;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Genero))
			return false;
		Genero other = (Genero) obj;
		if (idgenero != other.idgenero)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Genero [idgenero=" + idgenero + ", nombregenero=" + nombregenero + "]";
	}

}