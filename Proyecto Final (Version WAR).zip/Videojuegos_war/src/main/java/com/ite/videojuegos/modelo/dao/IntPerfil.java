package com.ite.videojuegos.modelo.dao;

import java.util.List;

import com.ite.videojuegos.modelo.beans.Perfil;

//Interfaz de los perfiles
public interface IntPerfil {

	List<Perfil> verPerfiles();

	Perfil verPerfil(int id);

}
