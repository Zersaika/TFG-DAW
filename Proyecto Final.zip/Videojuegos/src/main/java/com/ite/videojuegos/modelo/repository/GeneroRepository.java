package com.ite.videojuegos.modelo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ite.videojuegos.modelo.beans.Genero;

//Repositorio de los generos
public interface GeneroRepository extends JpaRepository<Genero, Integer> {

}
