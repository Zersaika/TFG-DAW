package com.ite.videojuegos.configuracion;

import java.nio.file.Path;
import java.nio.file.Paths;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebSecurity
public class DataBaseWebSecurity extends WebSecurityConfigurerAdapter implements WebMvcConfigurer {

	@Autowired
	private DataSource dataSource;

	// Método configure para la autenticación del usuario
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.jdbcAuthentication().dataSource(dataSource)
				.usersByUsernameQuery("select usuario,contrasena,'true' as enabled from Usuarios where usuario=?")
				.authoritiesByUsernameQuery("select u.usuario, p.nombre from perfilusuario up"
						+ " inner join Usuarios u on u.usuario = up.usuario inner join Perfil p on p.idperfil = up.idperfil "
						+ "where u.usuario = ?");

	}

	// Sobrecarga del método configure se establecen las urls en fución del perfil
	// del usuario o a las cuales se tiene acceso sin estar autenticado.

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable().authorizeRequests()

				// Permitimos el acceso a todos los metodos
				.antMatchers(HttpMethod.OPTIONS).permitAll().antMatchers(HttpMethod.GET).permitAll()
				.antMatchers(HttpMethod.POST).permitAll().antMatchers(HttpMethod.PUT).permitAll()
				.antMatchers(HttpMethod.DELETE).permitAll()

				// Los recursos estaticos no requieren autenticacion
				.antMatchers("/bootstrap/**", "/app-videojuegos/img**", "/css/**", "js/**").permitAll()

				// Las vistas publicas no requieren autenticacion
				.antMatchers("/", "/index", "/detalle/**", "/verVideojuegos/**", "/login", "/buscar", "/registro")
				.permitAll()

				// Asignar permisos a URLs por ROLES
				.antMatchers("/cliente/**").hasAuthority("Cliente").antMatchers("/admin/**")
				.hasAuthority("Administrador").antMatchers("/propietario/**").hasAuthority("Propietario")

				// Todas las demas URLs de la Aplicacion requieren autenticacion
				.anyRequest().authenticated()

				// El formulario de Login no requiere autenticacion
				.and().formLogin().loginPage("/login").defaultSuccessUrl("/").failureUrl("/login?error=true")
				.permitAll().and().logout().logoutSuccessUrl("/login?logout=true").invalidateHttpSession(true)
				.permitAll();
	}

	// Metodo para registrar las imagenes y las localizaciones de ellas
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		exposeDirectory("app-videojuegos/img", registry);
	}

	private void exposeDirectory(String dirName, ResourceHandlerRegistry registry) {
		Path uploadDir = Paths.get(dirName);
		String uploadPath = uploadDir.toFile().getAbsolutePath();

		if (dirName.startsWith("../"))
			dirName = dirName.replace("../", "");

		registry.addResourceHandler("/" + dirName + "/**").addResourceLocations("file:/" + uploadPath + "/");
	}

}
