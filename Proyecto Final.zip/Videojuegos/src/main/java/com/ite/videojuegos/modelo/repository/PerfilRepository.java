package com.ite.videojuegos.modelo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ite.videojuegos.modelo.beans.Perfil;

//Repositorio de los perfiles
public interface PerfilRepository extends JpaRepository<Perfil, Integer> {

}
