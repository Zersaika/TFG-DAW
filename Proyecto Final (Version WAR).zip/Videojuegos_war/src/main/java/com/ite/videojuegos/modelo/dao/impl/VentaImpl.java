package com.ite.videojuegos.modelo.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ite.videojuegos.modelo.beans.Venta;
import com.ite.videojuegos.modelo.dao.IntVenta;
import com.ite.videojuegos.modelo.repository.VentaRepository;

//Implementacion de la interfaz de las ventas
@Repository
public class VentaImpl implements IntVenta {

	@Autowired
	VentaRepository vrepo;

	// Metodo que accede al repositorio para ver una lista de las ventas
	@Override
	public List<Venta> verVentas() {
		// TODO Auto-generated method stub
		return vrepo.findAll();
	}

	// Metodo que permite crear una venta a la base de datos
	@Override
	public int crear(Venta venta) {
		int crear = 0;
		if (verVenta(venta.getIdventa()) == null) {
			vrepo.save(venta);
			crear = 1;
		}
		return crear;
	}

	// Metodo que permite ver una venta mediante su id
	@Override
	public Venta verVenta(int id) {
		// TODO Auto-generated method stub
		return vrepo.findById(id).orElse(null);
	}

}
