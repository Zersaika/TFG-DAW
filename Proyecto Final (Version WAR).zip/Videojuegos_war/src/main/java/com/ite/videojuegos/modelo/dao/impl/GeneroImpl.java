package com.ite.videojuegos.modelo.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ite.videojuegos.modelo.beans.Genero;
import com.ite.videojuegos.modelo.dao.IntGenero;
import com.ite.videojuegos.modelo.repository.GeneroRepository;

//Implementacion de la interfaz de los generos
@Repository
public class GeneroImpl implements IntGenero {

	@Autowired
	GeneroRepository grepo;

	// Metodo que permite ver un genero mediante su id
	@Override
	public Genero verGenero(int id) {
		// TODO Auto-generated method stub
		return grepo.findById(id).orElse(null);
	}

	// Metodo que permite crear un genero en la base de datos
	@Override
	public int crear(Genero genero) {
		int crear = 0;
		if (verGenero(genero.getIdgenero()) == null) {
			grepo.save(genero);
			crear = 1;
		}
		return crear;
	}

	// Metodo que permite modificar un genero en la base de datos
	@Override
	public int modificar(Genero genero) {
		int modificar = 0;
		if (verGenero(genero.getIdgenero()) != null) {
			grepo.save(genero);
			modificar = 1;
		}
		return modificar;
	}

	// Metodo que permite eliminar un genero en la base de datos
	@Override
	public int eliminar(int idGenero) {
		int eliminar = 0;
		if (verGenero(idGenero) != null) {
			try {
				grepo.deleteById(idGenero);
				eliminar = 1;
			} catch (Exception e) {
				eliminar = 0;
			}
		}
		return eliminar;
	}

	// Metodo que devuelve una lista con todos los generos
	@Override
	public List<Genero> verGeneros() {
		// TODO Auto-generated method stub
		return grepo.findAll();
	}

}
