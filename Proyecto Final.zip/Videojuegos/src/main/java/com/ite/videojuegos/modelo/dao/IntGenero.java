package com.ite.videojuegos.modelo.dao;

import java.util.List;

import com.ite.videojuegos.modelo.beans.Genero;

//Interfaz de los generos
public interface IntGenero {

	List<Genero> verGeneros();

	Genero verGenero(int id);

	int crear(Genero genero);

	int modificar(Genero genero);

	int eliminar(int idGenero);

}
