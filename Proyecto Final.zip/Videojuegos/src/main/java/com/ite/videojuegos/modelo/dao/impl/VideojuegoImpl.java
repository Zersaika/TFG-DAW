package com.ite.videojuegos.modelo.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ite.videojuegos.modelo.beans.Videojuego;
import com.ite.videojuegos.modelo.dao.IntVideojuego;
import com.ite.videojuegos.modelo.repository.VideojuegoRepository;

//Implementacion de la interfaz de las compras
@Repository
public class VideojuegoImpl implements IntVideojuego {

	@Autowired
	VideojuegoRepository vrepo;

	// Metodo que devuelve una lista de videojuegos
	@Override
	public List<Videojuego> verVideojuegos() {
		// TODO Auto-generated method stub
		return vrepo.findAll();
	}

	// Metodo que devuelve una lista de juegos por genero
	@Override
	public List<Videojuego> verVideojuegosPorGenero(int genero) {
		// TODO Auto-generated method stub
		return vrepo.mostrarVideojuegosPorGenero(genero);
	}

	// Metodo que devuelve una lista de juegos por su nombre
	@Override
	public List<Videojuego> verVideojuegosPorTitulo(String cadena) {
		// TODO Auto-generated method stub
		return vrepo.mostrarVideojuegosPorTitulo(cadena);
	}

	// Metodo para ver un videojuego mediante su id
	@Override
	public Videojuego verVideojuego(int id) {
		// TODO Auto-generated method stub
		return vrepo.findById(id).orElse(null);
	}

	// Metodo para crear un videojuego en la base de datos
	@Override
	public int crear(Videojuego videojuego) {
		int crear = 0;
		if (verVideojuego(videojuego.getIdvideojuego()) == null) {
			vrepo.save(videojuego);
			crear = 1;
		}
		return crear;
	}

	// Metodo para modificar un videojuego en la base de datos
	@Override
	public int modificar(Videojuego videojuego) {
		int modificar = 0;
		if (verVideojuego(videojuego.getIdvideojuego()) != null) {
			vrepo.save(videojuego);
			modificar = 1;
		}
		return modificar;
	}

	// Metodo para eliminar un videojuego en la base de datos
	@Override
	public int eliminar(int idVideojuego) {
		int eliminar = 0;
		if (verVideojuego(idVideojuego) != null) {
			try {
				vrepo.deleteById(idVideojuego);
				eliminar = 1;
			} catch (Exception e) {
				eliminar = 0;
			}
		}
		return eliminar;
	}

}
