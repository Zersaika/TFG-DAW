package com.ite.videojuegos.modelo.dao;

import java.util.List;

import com.ite.videojuegos.modelo.beans.Venta;

//Interfaz de las ventas
public interface IntVenta {

	List<Venta> verVentas();

	int crear(Venta venta);

	Venta verVenta(int id);

}
