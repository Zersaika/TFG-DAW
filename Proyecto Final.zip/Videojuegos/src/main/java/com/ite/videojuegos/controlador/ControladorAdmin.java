package com.ite.videojuegos.controlador;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ite.videojuegos.modelo.beans.Perfil;
import com.ite.videojuegos.modelo.beans.Usuario;
import com.ite.videojuegos.modelo.dao.IntPerfil;
import com.ite.videojuegos.modelo.dao.IntUsuario;

//Controlador del administrador
@Controller
@RequestMapping("/admin")
public class ControladorAdmin {

	@Autowired
	private IntUsuario udao;

	@Autowired
	private IntPerfil pdao;

	// Metodo para visualizar la lista de usuarios
	@GetMapping("/usuarios")
	public String usuarios(Model model) {

		model.addAttribute("usuarios", udao.mostrarTodosUsuarios());

		return "usuarios";
	}

	// Metodo para modificar un usuario mediante su nombre de usuario
	@GetMapping("/modificarUsuario/{usuario}")
	public String modificarUsuario(@PathVariable("usuario") String usuario, Model model) {

		model.addAttribute("usuario", udao.verUsuario(usuario));

		return "modificarUsuario";
	}

	// Metodo para modificar el perfil de un usuario
	@PostMapping("/modificarUsuario/{usuario}")
	public String procModificarUsuario(@PathVariable("usuario") String usuario, RedirectAttributes rattr,
			Usuario usuarioaux, Perfil perfil) {
		Usuario u = udao.verUsuario(usuario);

		if (perfil.getIdperfil() == 0) {
			System.out.println("No hay que cambiar el perfil");
		} else {
			List<Perfil> lista = new ArrayList<Perfil>();
			Perfil p = pdao.verPerfil(perfil.getIdperfil());
			lista.add(p);
			u.setPerfils(lista);
		}

		int reg = udao.modificar(u);
		if (reg == 0) {
			System.out.println("Usuario no modificado");
			rattr.addFlashAttribute("mensaje", "El usuario no se ha modificado");
		} else {
			System.out.println("Usuario modificado");
			rattr.addFlashAttribute("mensaje", "El usuario se ha modificado");
		}

		return "redirect:/admin/usuarios";
	}

	// Metodo para eliminar un usuario mediante su nombre de usuario
	@GetMapping("/eliminarUsuario/{usuario}")
	public String eliminarUsuario(@PathVariable("usuario") String usuario, RedirectAttributes rattr) {
		int reg = udao.eliminar(usuario);
		if (reg == 0) {
			System.out.println("Usuario no eliminado");
			rattr.addFlashAttribute("mensaje", "No se puede eliminar un usuario con pedidos hechos");
		} else {
			System.out.println("Usuario eliminado");
			rattr.addFlashAttribute("mensaje", "El usuario se ha eliminado");
		}

		return "redirect:/admin/usuarios";
	}

}
