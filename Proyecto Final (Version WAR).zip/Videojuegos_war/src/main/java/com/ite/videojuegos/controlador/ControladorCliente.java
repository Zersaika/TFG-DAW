package com.ite.videojuegos.controlador;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ite.videojuegos.modelo.beans.Compra;
import com.ite.videojuegos.modelo.beans.Usuario;
import com.ite.videojuegos.modelo.beans.Venta;
import com.ite.videojuegos.modelo.beans.Videojuego;
import com.ite.videojuegos.modelo.dao.IntCompra;
import com.ite.videojuegos.modelo.dao.IntUsuario;
import com.ite.videojuegos.modelo.dao.IntVenta;
import com.ite.videojuegos.modelo.dao.IntVideojuego;

//Controlador del cliente
@Controller
@RequestMapping("/cliente")
public class ControladorCliente {

	@Autowired
	private IntUsuario udao;

	@Autowired
	private IntVideojuego vdao;

	@Autowired
	private IntVenta vedao;

	@Autowired
	private IntCompra cdao;

	// Metodo para ver los datos del cliente
	@GetMapping("/datos")
	public String datos(Authentication aut, Model model) {
		// Encontramos los datos mediante el nombre de usuario que ha iniciado sesion
		model.addAttribute("cliente", udao.verUsuario(aut.getName()));

		return "misdatos";

	}

	// Metodo que nos redirige al carrito de la compra
	@GetMapping("/carrito")
	public String carrito() {

		return "verCarro";

	}

	// Metodo que añade un videojuego al carrito mediante su id
	@SuppressWarnings("unchecked")
	@GetMapping("/añadirCarrito/{id}")
	public String añadirCarrito(@PathVariable("id") int id, HttpSession sesion, Model model) {

		// Creamos una lista de videojuegos en sesion
		List<Videojuego> carrito = (List<Videojuego>) sesion.getAttribute("carrito");

		// Si esta vacia es de tipo arraylist
		if (carrito == null) {
			carrito = new ArrayList<Videojuego>();
		}

		// Finalmente añadimos el videojuego al carrito
		carrito.add(vdao.verVideojuego(id));
		sesion.setAttribute("carrito", carrito);
		model.addAttribute("mensaje", "Añadido al carrito");

		return "forward:/detalle/" + id;

	}

	// Metodo que elimina un videojuego del carrito mediante su id
	@SuppressWarnings("unchecked")
	@GetMapping("/eliminarCarrito/{id}")
	public String eliminarCarrito(@PathVariable("id") int id, HttpSession sesion, Model model) {

		// Eliminamos del la lista en sesion el videojuego mediante su id
		((List<Videojuego>) sesion.getAttribute("carrito")).remove(vdao.verVideojuego(id));

		model.addAttribute("mensaje", "Eliminado del carrito");

		return "verCarro";
	}

	// Metodo que nos redirige a la pagina de añadir dinero
	@GetMapping("/añadirDinero")
	public String añadirDinero() {

		return "añadirDinero";

	}

	// Metodo que procesa el añadir dinero
	@PostMapping("/añadirDinero")
	public String procAñadirDinero(HttpSession sesion, Usuario uaux, RedirectAttributes rattr) {
		// Cogemos el usuario de la sesion y vemos cuanto dinero tiene
		Usuario usuario = (Usuario) sesion.getAttribute("usuario");
		Double dinero = usuario.getDinero();

		// Cogemos el dinero que pasamos mas el que tiene y lo modificamos en su perfil
		Double dineroTotal = dinero + uaux.getDinero();
		usuario.setDinero(dineroTotal);

		int reg = udao.modificar(usuario);
		if (reg == 0) {

			System.out.println("Dinero no añadido");
			rattr.addFlashAttribute("mensaje", "El dinero no se ha añadido");

		} else {

			System.out.println("Dinero añadido");
			rattr.addFlashAttribute("mensaje", "El dinero se ha añadido");

		}

		return "redirect:/";
	}

	// Metodo que nos redirige a la pagina de modificar datos
	@GetMapping("/modificarDatos")
	public String modificarDatos(Authentication aut, Model model) {
		// Encontramos los datos mediante el nombre de usuario que ha iniciado sesion
		model.addAttribute("cliente", udao.verUsuario(aut.getName()));
		return "modificarDatos";
	}

	// Metodo para modificar los datos de los usuarios
	@PostMapping("/modificarDatos")
	public String procModificarDatos(HttpSession sesion, Usuario u, RedirectAttributes rattr) {
		Usuario usuario = (Usuario) sesion.getAttribute("usuario");
		// Si algun hueco del formulario esta vacio , este no se va a a cambiar

		if (u.getUsuario().isEmpty()) {
			System.out.println("No hay que cambiar el usuario");
		} else {
			usuario.setUsuario(u.getUsuario());
		}

		if (u.getContrasena().isEmpty()) {
			System.out.println("No hay que cambiar la contraseña");
		} else {
			usuario.setContrasena("{noop}" + u.getContrasena());
		}

		if (u.getNombre().isEmpty()) {
			System.out.println("No hay que cambiar el nombre");
		} else {
			usuario.setNombre(u.getNombre());
		}

		if (u.getApellido().isEmpty()) {
			System.out.println("No hay que cambiar el apellido");
		} else {
			usuario.setApellido(u.getApellido());
		}

		if (u.getDireccion().isEmpty()) {
			System.out.println("No hay que cambiar la direccion");
		} else {
			usuario.setDireccion(u.getDireccion());
		}

		if (u.getEmail().isEmpty()) {
			System.out.println("No hay que cambiar el email");
		} else {
			usuario.setEmail(u.getEmail());
		}

		if (u.getTelefono().isEmpty()) {
			System.out.println("No hay que cambiar el telefono");
		} else {
			usuario.setTelefono(u.getTelefono());
		}

		int reg = udao.modificar(usuario);
		if (reg == 0) {
			System.out.println("Datos no cambiados");
			rattr.addFlashAttribute("mensaje", "Los datos no han sido modificados");
		} else {
			System.out.println("Datos cambiados");
			rattr.addFlashAttribute("mensaje", "Los datos han sido modificados");
		}

		return "redirect:/cliente/datos";
	}

	// Metodo para comprar videojuegos
	@SuppressWarnings("unchecked")
	@GetMapping("/comprar")
	public String comprar(HttpSession sesion, RedirectAttributes rattr) {

		// Accedemos a la lista del carrito
		List<Videojuego> carrito = (List<Videojuego>) sesion.getAttribute("carrito");

		// Vamos a trabajar con una copia del carrito pra que no de errores de ejecucion
		List<Videojuego> carritoaux = new ArrayList<Videojuego>();
		carritoaux.addAll(carrito);

		Usuario usuario = (Usuario) sesion.getAttribute("usuario");

		// Inicializamos a 0 el total del dinero que nos va a costar
		double total = 0;

		for (Videojuego vaux : carritoaux) {
			total = total + vaux.getPrecio();
		}
		System.out.println(total);

		// Calculamos el dinero que va a costar la compra, si el usuario tiene menos
		// dinero no podra realizarla
		double dinerousuario = usuario.getDinero();
		if (dinerousuario <= total) {
			System.out.println("No se puede hacer la compra");
			rattr.addFlashAttribute("mensaje", "Falta dinero");
		} else {

			// Recorremos el carrito y vamos eliminando cada elemento uno por uno y creando
			// una compra de ese videojuego
			for (Videojuego v : carritoaux) {
				Double dinero = usuario.getDinero();
				usuario.setDinero(dinero - v.getPrecio());

				// Crear compra
				Compra c = new Compra();
				c.setAsunto("Compra de videojuego");
				c.setUsuarioBean(usuario);
				c.setVideojuego(v);
				carrito.remove(vdao.verVideojuego(v.getIdvideojuego()));
				int reg = cdao.crear(c);
				if (reg == 0) {
					System.out.println("Compra no hecha");
				} else {
					System.out.println("Compra hecha");
					int regu = udao.modificar(usuario);
					if (regu == 0) {
						System.out.println("Dinero no restado");
					} else {
						System.out.println("Dinero restado");

					}
					rattr.addFlashAttribute("mensaje", "Compra realizada");
				}
			}

		}

		return "redirect:/";

	}

	@GetMapping("/vender/{id}")
	public String Vender(@PathVariable("id") int id, HttpSession sesion, RedirectAttributes rattr, Model model) {

		model.addAttribute("videojuego", vdao.verVideojuego(id));
		return "confirmarVenta";

	}

	// Metodo para vender videojuegos
	@PostMapping("/vender/{id}")
	public String procVender(@PathVariable("id") int id, HttpSession sesion, RedirectAttributes rattr) {
		Usuario usuario = (Usuario) sesion.getAttribute("usuario");
		Videojuego v = vdao.verVideojuego(id);

		double dinero = v.getPrecio();
		double dinerou = usuario.getDinero();

		// Creamos venta
		Venta venta = new Venta();
		venta.setAsunto("Venta de videojuego");
		venta.setUsuarioBean(usuario);
		venta.setVideojuego(v);

		int reg = vedao.crear(venta);
		if (reg == 0) {
			System.out.println("Venta no hecha");
			rattr.addFlashAttribute("mensaje", "Venta no realizada");
		} else {
			System.out.println("Venta realizada");
			usuario.setDinero(dinero + dinerou);
			int regu = udao.modificar(usuario);
			if (regu == 0) {
				System.out.println("Dinero no sumado");
			} else {
				System.out.println("Dinero sumado");
			}
			rattr.addFlashAttribute("mensaje", "Venta realizada");
		}

		return "redirect:/";

	}

}
