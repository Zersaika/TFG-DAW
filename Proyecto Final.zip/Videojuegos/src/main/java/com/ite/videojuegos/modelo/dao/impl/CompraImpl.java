package com.ite.videojuegos.modelo.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ite.videojuegos.modelo.beans.Compra;
import com.ite.videojuegos.modelo.dao.IntCompra;
import com.ite.videojuegos.modelo.repository.CompraRepository;

//Implementacion de la interfaz de las compras
@Repository
public class CompraImpl implements IntCompra {

	@Autowired
	CompraRepository crepo;

	// Metodo que accede al repositorio para ver una lista de las compras
	@Override
	public List<Compra> verCompras() {
		// TODO Auto-generated method stub
		return crepo.findAll();
	}

	// Metodo que permite crear una compra a la base de datos
	@Override
	public int crear(Compra compra) {
		int crear = 0;
		if (verCompra(compra.getIdcompra()) == null) {
			crepo.save(compra);
			crear = 1;
		}
		return crear;
	}

	// Metodo que permite ver una compra mediante su id
	@Override
	public Compra verCompra(int id) {
		// TODO Auto-generated method stub
		return crepo.findById(id).orElse(null);
	}

}
