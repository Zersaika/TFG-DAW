package com.ite.videojuegos.modelo.dao;

import java.util.List;

import com.ite.videojuegos.modelo.beans.Videojuego;

//Interfaz de los videojuegos
public interface IntVideojuego {

	List<Videojuego> verVideojuegos();

	List<Videojuego> verVideojuegosPorGenero(int genero);

	List<Videojuego> verVideojuegosPorTitulo(String cadena);

	Videojuego verVideojuego(int id);

	int crear(Videojuego videojuego);

	int modificar(Videojuego videojuego);

	int eliminar(int idVideojuego);

}
