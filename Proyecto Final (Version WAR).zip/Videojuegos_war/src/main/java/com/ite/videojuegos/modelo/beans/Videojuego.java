package com.ite.videojuegos.modelo.beans;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the videojuegos database table.
 * 
 */
@Entity
@Table(name = "videojuegos")
@NamedQuery(name = "Videojuego.findAll", query = "SELECT v FROM Videojuego v")
public class Videojuego implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idvideojuego;

	@Lob
	private String descripcion;

	private String distribuidora;

	private String imagen;

	private double precio;

	private String titulo;

	// uni-directional many-to-one association to Genero
	@ManyToOne
	@JoinColumn(name = "IDGENERO")
	private Genero genero;

	public Videojuego() {
	}

	public int getIdvideojuego() {
		return this.idvideojuego;
	}

	public void setIdvideojuego(int idvideojuego) {
		this.idvideojuego = idvideojuego;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getDistribuidora() {
		return this.distribuidora;
	}

	public void setDistribuidora(String distribuidora) {
		this.distribuidora = distribuidora;
	}

	public String getImagen() {
		return "/app-videojuegos/img/" + this.imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public double getPrecio() {
		return this.precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getTitulo() {
		return this.titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public Genero getGenero() {
		return this.genero;
	}

	public void setGenero(Genero genero) {
		this.genero = genero;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + idvideojuego;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Videojuego))
			return false;
		Videojuego other = (Videojuego) obj;
		if (idvideojuego != other.idvideojuego)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Videojuego [idvideojuego=" + idvideojuego + ", descripcion=" + descripcion + ", distribuidora="
				+ distribuidora + ", imagen=" + imagen + ", precio=" + precio + ", titulo=" + titulo + ", genero="
				+ genero + "]";
	}

}