package com.ite.videojuegos.modelo.dao;

import java.util.List;

import com.ite.videojuegos.modelo.beans.Compra;

//Interfaz de las compras
public interface IntCompra {

	List<Compra> verCompras();

	int crear(Compra compra);

	Compra verCompra(int id);

}
