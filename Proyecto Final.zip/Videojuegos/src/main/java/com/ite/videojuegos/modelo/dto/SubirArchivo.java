package com.ite.videojuegos.modelo.dto;

import java.io.*;
import java.nio.file.*;

import org.springframework.web.multipart.MultipartFile;

public class SubirArchivo {

	// Metodo para guardar el archivo de imagen en una direccion
	public static void guardarArchivo(String directorio, String archivo, MultipartFile multipartFile) throws IOException {
		Path directoriosubida = Paths.get(directorio);
		// Si el archivo no existe en el directorio lo creamos
		if (!Files.exists(directoriosubida)) {
			Files.createDirectories(directoriosubida);
		}

		// Intentamos subirlo
		try (InputStream inputStream = multipartFile.getInputStream()) {
			Path filePath = directoriosubida.resolve(archivo);
			Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException ioe) {
			throw new IOException("No se puede guardar: " + archivo, ioe);
		}
	}
}