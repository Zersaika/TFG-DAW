package com.ite.videojuegos.modelo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ite.videojuegos.modelo.beans.Videojuego;

//Repositorio de los videojuegos
public interface VideojuegoRepository extends JpaRepository<Videojuego, Integer> {

	// Utilizamos JPQL para una sentencia personalizada a la base de datos, en el
	// primer caso para acceder al genero y en el segundo caso para introducir una
	// cadena de numeros o texto
	@Query("select v from Videojuego v where v.genero.idgenero = ?1")
	public List<Videojuego> mostrarVideojuegosPorGenero(int genero);

	@Query("select v from Videojuego v where v.titulo like %?1%")
	public List<Videojuego> mostrarVideojuegosPorTitulo(String titulo);
}
