package com.ite.videojuegos.modelo.beans;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the ventas database table.
 * 
 */
@Entity
@Table(name = "ventas")
@NamedQuery(name = "Venta.findAll", query = "SELECT v FROM Venta v")
public class Venta implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idventa;

	private String asunto;

	// uni-directional many-to-one association to Usuario
	@ManyToOne
	@JoinColumn(name = "USUARIO")
	private Usuario usuarioBean;

	// uni-directional many-to-one association to Videojuego
	@ManyToOne
	@JoinColumn(name = "IDVIDEOJUEGO")
	private Videojuego videojuego;

	public Venta() {
	}

	public int getIdventa() {
		return this.idventa;
	}

	public void setIdventa(int idventa) {
		this.idventa = idventa;
	}

	public String getAsunto() {
		return this.asunto;
	}

	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}

	public Usuario getUsuarioBean() {
		return this.usuarioBean;
	}

	public void setUsuarioBean(Usuario usuarioBean) {
		this.usuarioBean = usuarioBean;
	}

	public Videojuego getVideojuego() {
		return this.videojuego;
	}

	public void setVideojuego(Videojuego videojuego) {
		this.videojuego = videojuego;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + idventa;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Venta))
			return false;
		Venta other = (Venta) obj;
		if (idventa != other.idventa)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Venta [idventa=" + idventa + ", asunto=" + asunto + ", usuarioBean=" + usuarioBean + ", videojuego="
				+ videojuego + "]";
	}

}